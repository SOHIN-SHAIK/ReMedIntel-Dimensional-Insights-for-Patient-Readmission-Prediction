import os
os.makedirs("models", exist_ok=True)

import pandas as pd
import joblib
import tensorflow as tf
from sklearn.linear_model import LogisticRegression
from sklearn.tree import DecisionTreeRegressor
from sklearn.model_selection import train_test_split

def train_models():
    df = pd.read_csv('data/reduced_data.csv')
    X = df[['PCA1', 'PCA2', 'PCA3']]
    y = df['Readmitted_Days']
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2)

    # Logistic Regression
    log_model = LogisticRegression()
    log_model.fit(X_train, y_train)
    joblib.dump(log_model, 'models/logistic_model.pkl')

    # Decision Tree
    tree_model = DecisionTreeRegressor()
    tree_model.fit(X_train, y_train)
    joblib.dump(tree_model, 'models/tree_model.pkl')

    # Deep Learning
    dl_model = tf.keras.Sequential([
        tf.keras.layers.Dense(16, activation='relu', input_shape=(3,)),
        tf.keras.layers.Dense(1)
    ])
    dl_model.compile(optimizer='adam', loss='mae')
    dl_model.fit(X_train, y_train, epochs=30, verbose=0)
    dl_model.save('models/dl_model.h5')

if __name__ == "__main__":
    train_models()

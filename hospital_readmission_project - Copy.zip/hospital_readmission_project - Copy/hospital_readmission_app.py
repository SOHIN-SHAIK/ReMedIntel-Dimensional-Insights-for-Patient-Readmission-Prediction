import pandas as pd
import joblib
import streamlit as st
import tensorflow as tf
from sklearn.preprocessing import LabelEncoder
from datetime import datetime

# Use absolute paths to avoid FileNotFoundError
df = pd.read_csv(r"C:\Users\Shaik Sohin\OneDrive\Desktop\hospital_readmission_project - Copy\data\patient_data.csv")
df_reduced = pd.read_csv(r"C:\Users\Shaik Sohin\OneDrive\Desktop\hospital_readmission_project - Copy\data\reduced_data_v2.csv")

log_model = joblib.load(r"C:\Users\Shaik Sohin\OneDrive\Desktop\hospital_readmission_project - Copy\models\logistic_model.pkl")
tree_model = joblib.load(r"C:\Users\Shaik Sohin\OneDrive\Desktop\hospital_readmission_project - Copy\models\tree_model.pkl")
dl_model = tf.keras.models.load_model(r"C:\Users\Shaik Sohin\OneDrive\Desktop\hospital_readmission_project - Copy\models\dl_model.h5")

st.title("🏥 Hospital Patient Readmission Prediction")

option = st.selectbox("Choose a prediction mode", ["Predict by Patient Name", "Predict by Time Period"])

if option == "Predict by Patient Name":
    name = st.selectbox("Select patient", df['Name'].unique())
    patient = df[df['Name'] == name].iloc[0]
    st.write("Patient Info:", patient)

    idx = df_reduced[df_reduced['Name'] == name].index[0]
    input_data = df_reduced.loc[idx, ['PCA1', 'PCA2', 'PCA3']].values.reshape(1, -1)

    if st.button("Predict Readmission Days"):
        pred_dl = dl_model.predict(input_data)[0][0]
        st.success(f"Predicted Readmission Days: {int(pred_dl)}")

elif option == "Predict by Time Period":
    days = st.slider("Select days for prediction", 1, 100)
    predictions = []
    for i in range(len(df_reduced)):
        input_data = df_reduced.iloc[i][['PCA1', 'PCA2', 'PCA3']].values.reshape(1, -1)
        pred_days = dl_model.predict(input_data)[0][0]
        if pred_days <= days:
            predictions.append(df_reduced.iloc[i]['Name'])
    st.write(f"Patients likely to be readmitted in {days} days:")
    st.write(predictions)
